import 'package:flutter/material.dart';
import 'package:bmi_app/bmi_app/input_screen.dart'; // Import màn hình nhập thông tin BMI

void main() {
  runApp(const BmiApp());
}

class BmiApp extends StatelessWidget {
  const BmiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Ẩn debug banner
      title: 'BMI Calculator',
      theme: ThemeData.dark(), // Có thể tùy chỉnh theme
      home: const BmiInputScreen(), // Màn hình đầu tiên sẽ là nhập BMI
    );
  }
}
