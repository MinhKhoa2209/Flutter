package com.example.quizzler_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
