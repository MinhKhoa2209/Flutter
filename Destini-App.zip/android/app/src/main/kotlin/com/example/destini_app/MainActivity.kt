package com.example.destini_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
