import 'package:flutter/material.dart';
import 'i_am_poor.dart'; // Import màn hình IAmPoorScreen

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'I Am Poor App',
      theme: ThemeData(
        primarySwatch: Colors.brown,
      ),
      home: const IAmPoor(), // Thay đổi màn hình mặc định
    );
  }
}
