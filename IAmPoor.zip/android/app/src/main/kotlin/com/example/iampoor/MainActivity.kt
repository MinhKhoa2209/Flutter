package com.example.iampoor

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
